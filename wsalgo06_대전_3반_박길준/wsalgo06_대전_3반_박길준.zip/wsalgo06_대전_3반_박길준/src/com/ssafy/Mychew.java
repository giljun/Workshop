package com.ssafy;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Mychew {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Person> queue = new LinkedList<Person>();

		Scanner sc = new Scanner(System.in);
		System.out.print("마이쮸의 개수를 입력해주세요. : ");
		// 마이츄의 갯수를 입력한다.
		int mychew = sc.nextInt();

		// 마이쮸를 받는 사람을 임시변수로 선언한다.
		Person receiver = null;

		int pNum = 1;
		// 1. 큐에서 한명을 뽑는다.
		// 2. 뽑으면서 방문 수를 확인하여, 방문 수만큼의 마이쮸를 전체 마이쮸의 갯수에서 뺀다.
		while (mychew > 0) {
			queue.add(new Person(pNum++, 1));
			receiver = queue.poll();
			if (mychew - receiver.getcnt() < 0) {
				mychew = 0;
			} else {
				mychew = mychew - receiver.getcnt();
			}
			receiver.upcnt(); // 마이쮸를 받았기 때문에, 다음에 받을 땐 하나 더 추가된다.
			queue.add(receiver);
		}
		
		System.out.println("마지막으로 마이쮸를 받은 친구는?" + receiver.getnum() + "번입니다.");
	}

}

class Person {
	private int num;
	private int cnt;

	Person(int num, int cnt) {
		this.num = num;
		this.cnt = cnt;
	}

	public int getcnt() {
		return cnt;
	}

	public void upcnt() {
		cnt++;
	}
	
	public int getnum() {
		return num;
	}
}